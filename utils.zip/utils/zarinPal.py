# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.shortcuts import redirect
import requests
import json

ZP_API_REQUEST = "https://sandbox.zarinpal.com/pg/v4/payment/request.json"
ZP_API_VERIFY = "https://sandbox.zarinpal.com/pg/v4/payment/verify.json"
ZP_API_STARTPAY = "https://sandbox.zarinpal.com/pg/StartPay/"


IDPAYREQ = "https://api.idpay.ir/v1.1/payment"
IDPAYVERIFY = "https://api.idpay.ir/v1.1/payment/verify"

IDPAYHEADER = {"accept": "application/json",
                  "content-type": "application/json",
                  "X-API-KEY":"6a7f99eb-7c20-4412-a972-6dfb7cd253a4",
                  "X-SANDBOX": "1",
                  }

MERCHANT = '1344b5d4-0048-11e8-94db-005056a205be'
# ZP_API_REQUEST = "https://api.zarinpal.com/pg/v4/payment/request.json"
# ZP_API_VERIFY = "https://api.zarinpal.com/pg/v4/payment/verify.json"
# ZP_API_STARTPAY = "https://www.zarinpal.com/pg/StartPay/{authority}"
# AMOUNT = 11000  # Rial / Required
# description = "توضیحات مربوط به تراکنش را در این قسمت وارد کنید"  # Required
# email = 'email@example.com'  # Optional
# mobile = '09123456789'  # Optional
# Important: need to edit for realy server.
# CallbackURL = 'http://localhost:8000/verify/'


def send_payment_request(price, CallbackURL, desc, mobile, email):
    req_data = {
        "merchant_id": MERCHANT,
        "amount": int(price),
        "callback_url": CallbackURL,
        "description": desc,
        # "metadata": {"mobile": mobile, "email": email}
    }
    req_header = {"accept": "application/json",
                  "content-type": "application/json"}
    req = requests.post(url=ZP_API_REQUEST, data=json.dumps(
        req_data), headers=req_header)
    # authority = req.json()['data']['authority']
    # authority = req.json()
    # print(req)
    # print(req_data)
    print(json.dumps(req_data))
    print(req)

    # if len(req.json()['errors']) == 0:
    #     return redirect(ZP_API_STARTPAY.format(authority=authority))
    # else:
    #     e_code = req.json()['errors']['code']
    #     e_message = req.json()['errors']['message']
    #     return HttpResponse(f"Error code: {e_code}, Error Message: {e_message}")


# def verify(request, price):
#     t_status = request.GET.get('Status')
#     t_authority = request.GET['Authority']
#     if request.GET.get('Status') == 'OK':
#         req_header = {"accept": "application/json",
#                       "content-type": "application/json'"}
#         req_data = {
#             "merchant_id": MERCHANT,
#             "amount": price,
#             "authority": t_authority
#         }
#         req = requests.post(url=ZP_API_VERIFY, data=json.dumps(req_data), headers=req_header)
#         if len(req.json()['errors']) == 0:
#             t_status = req.json()['data']['code']
#             if t_status == 100:
#                 return HttpResponse('Transaction success.\nRefID: ' + str(
#                     req.json()['data']['ref_id']
#                 ))
#             elif t_status == 101:
#                 return HttpResponse('Transaction submitted : ' + str(
#                     req.json()['data']['message']
#                 ))
#             else:
#                 return HttpResponse('Transaction failed.\nStatus: ' + str(
#                     req.json()['data']['message']
#                 ))
#         else:
#             e_code = req.json()['errors']['code']
#             e_message = req.json()['errors']['message']
#             return HttpResponse(f"Error code: {e_code}, Error Message: {e_message}")
#     else:
#         return HttpResponse('Transaction failed or canceled by user')

def send_payment_request_idpay(order_id, price, c_name, phone, mail, desc, CallbackURL):
    
    req_data = {
    "order_id": int(order_id),
    "amount": int(price),
    "name": c_name,
    "phone": phone,
    "mail": mail,
    "desc": desc,
    "callback": CallbackURL
    }
    
    req = requests.post(url=IDPAYREQ, data=json.dumps(
        req_data), headers=IDPAYHEADER)
    pobj = req.json()
    payment_list = [pobj["id"], pobj["link"]]
    
    return  payment_list


def send_verify_idpay(pay_id, order_id):

    req_data = {
        "id": pay_id,
        "order_id": order_id
    }

    req = requests.post(url=IDPAYVERIFY, data=json.dumps(req_data), headers=IDPAYHEADER)

    pobj = req.json()
    rep = [
            pobj["status"],
            pobj["id"],
            pobj["track_id"],
            {
                "payment":pobj['payment']["track_id"]
            } 
            ]
    return rep
    


# send_verify_idpay(
#     send_payment_request_idpay(101, 20000,
#      "sadeq", "12", "ss", "orde2", "http://127.0.0.1:8000/")[0],
#     101
# )
# vc =send_payment_request_idpay(101, 20000,
#      "sadeq", "12", "ss", "orde2", "http://127.0.0.1:8000/")

# print(vc)

# print(send_verify_idpay("5a8b849e76af46cd4b1d552ad62bc87c", 101))
